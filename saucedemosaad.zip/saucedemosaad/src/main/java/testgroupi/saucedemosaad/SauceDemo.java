package testgroupi.saucedemosaad;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SauceDemo {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		// System Property for Chrome Driver   
        System.setProperty("webdriver.chrome.driver", "F:\\chromedriver_win32\\chromedriver_win32\\chromedriver.exe");  
          
             // Instantiate a ChromeDriver class.     
        WebDriver driver=new ChromeDriver();  
          
           // Launch Website  
        driver.navigate().to("http:saucedemo.com/"); 
        WebElement username=driver.findElement(By.id("user-name"));
        username.sendKeys("standard_user");
        
        WebElement password=driver.findElement(By.id("password"));
        password.sendKeys("secret_sauce");
        
        driver.findElement(By.id("login-button")).click();
        driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();
        driver.findElement(By.id("remove-sauce-labs-backpack")).click();
        driver.findElement(By.id("add-to-cart-sauce-labs-bike-light")).click();
        
        driver.findElement(By.xpath("//*[@id=\"header_container\"]/div[2]/div/span/select")).click();
        
        
        driver.findElement(By.id("react-burger-menu-btn")).click();
        Thread.sleep(3000);
        driver.findElement(By.id("logout_sidebar_link")).click();
        
        
        
        
        
          
         //Maximize the browser  
          driver.manage().window().maximize();  
         // driver.quit();

	}

}
